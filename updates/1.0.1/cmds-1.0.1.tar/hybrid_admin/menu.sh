#!/usr/bin/env bash
# /root/.hybrid_admin/menu.sh
# Hybrid (Device Local) menu with dynamic help, completion checkmarks, and submenus.
# Behavior:
#   - Cancel/Esc in submenus => return to main menu (do NOT exit menu.sh)
#   - Cancel/Esc in main menu => exit menu.sh (return to parent launcher)

set -Eeuo pipefail

need(){ command -v "$1" >/dev/null 2>&1 || { echo "Missing: $1" >&2; exit 1; }; }
need dialog

BACKTITLE="CMDS-Deployment Server"
TITLE="Catalyst to Meraki (hybrid) (Device Local)"

# Colors (dialog --colors)
HELP_COLOR_PREFIX="${HELP_COLOR_PREFIX:-\Zb\Z3}"  # bold yellow
HELP_COLOR_RESET="${HELP_COLOR_RESET:-\Zn}"
MARK_CHECK="${MARK_CHECK:-\Z2\Zb[✓]\Zn}"          # bold green [✓]

DIALOG_OPTS=(--no-shadow --colors --item-help --backtitle "$BACKTITLE")

cleanup(){ clear; }
trap cleanup EXIT

# -----------------------------------------------------------------------------
# dialog wrapper — renders to tty; captures selection from stdout
# Populates:
#   DIALOG_RC : 0=OK, 1=Cancel, 255=Esc
#   DOUT      : selected tag
# -----------------------------------------------------------------------------
dlg() {
  local out rc
  set +e
  out="$(dialog "${DIALOG_OPTS[@]}" --stdout "$@")"
  rc=$?
  set -e
  DIALOG_RC=$rc
  DOUT="$out"
  return 0
}

# Map menu labels -> artifact file that indicates completion
declare -A DONE_FILE=(
  ["Setup Wizard"]="/root/.hybrid_admin/meraki_discovery.env"
  ["Switch Discovery"]="/root/.hybrid_admin/selected_upgrade.env"
  ["Validate IOS-XE configuration"]="/root/.hybrid_admin/preflight_validated.flag"
  ["Migrate Switches"]="/root/.hybrid_admin/meraki_claim.log"   # symlink to latest claim log
)

# Items: label -> script path
declare -A ITEMS=(
  ["Setup Wizard"]="/root/.hybrid_admin/setupwizard.sh"
  ["Switch Discovery"]="/root/.hybrid_admin/discoverswitches.sh"
  ["Validate IOS-XE configuration"]="/root/.hybrid_admin/meraki_preflight.sh"
  ["IOS-XE Upgrade"]=""  # submenu
  ["Migrate Switches"]="/root/.hybrid_admin/migration.sh"
  ["Logging"]="/root/.hybrid_admin/show_logs.sh"
  ["Clean Configuration (New Batch Deployment)"]="/root/.hybrid_admin/clean.sh"
  ["Utilities"]=""  # submenu
  ["Server Management"]=""  # header/separator
  ["Backup & Restore"]=""   # submenu   <<< NEW
  ["Server Service Control"]=""  # submenu
  ["README"]="/root/.hybrid_admin/readme.sh"
)

# Submenus: label -> function name
declare -A SUBMENU_FN=(
  ["IOS-XE Upgrade"]="submenu_iosxe"
  ["Utilities"]="submenu_utilities"
  ["Backup & Restore"]="submenu_backup_restore"     # <<< NEW
  ["Server Service Control"]="submenu_server_services"
)

# Per-item help (status line)
declare -A HELP_RAW=(
  ["Setup Wizard"]="Guided Setup: Always run between batches (API keys, credentials)"
  ["Switch Discovery"]="Discover live Catalyst switches, probe via SSH, and build the selection for upgrades."
  ["Validate IOS-XE configuration"]="Run preflight validation for selected switches and configuration before upgrade."
  ["IOS-XE Upgrade"]="Run IOS-XE install/activate/commit workflows and tools."
  ["Deploy IOS-XE"]="Copy image to flash, then install/activate/commit on selected switches."
  ["Schedule Image Upgrade"]="Schedule a future image upgrade (snapshots envs, uses 'at')."
  ["Migrate Switches"]="Run the Catalyst-to-Meraki switch migration workflow and claim devices into Dashboard."
  ["Logging"]="View CMDS deployment and migration log files."
  ["Clean Configuration (New Batch Deployment)"]="Clear previous selections and files to prepare a new batch deployment."
  ["Utilities"]="Utility tools for monitoring and quick checks."
  ["Switch UP/Down Status"]="Monitor switch reachability (UP/DOWN) using continuous ping."
  ["Advanced IOS-XE deployment"]="Advanced IOS-XE deployment tools (interactive, scheduled, and schedule viewer)."
  ["Advanced IOS-XE Deployment (Interactive)"]="Run the advanced IOS-XE deployment interactively (manual, no guardrails)."
  ["Advanced IOS-XE Deployment (Scheduled)"]="Schedule the advanced IOS-XE deployment workflow."
  ["View Advanced Schedules"]="View scheduled advanced IOS-XE jobs and related logs."
  ["IOS-XE Image Management"]="Manage IOS-XE image files (list, inspect, and clean up)."
  ["CLI Updater"]="Run ad-hoc CLI command packs on selected switches."
  ["Backup Config Viewer"]="Browse and search saved switch backup configs."
  ["CMDS Updater"]="Download and apply CMDS updates from GitHub (with dry-run and patch history logging)."
  ["Server Management"]="Server management tools and utilities."
  ["Backup & Restore"]="Backup, schedule, and restore CMDS data (local or remote)."     # <<< NEW
  ["Backup (Local/Remote)"]="Run CMDS backups (local and remote with SSH)"  # <<< NEW
  ["Backup Scheduler"]="Schedule recurring backups"      # <<< NEW
  ["Restore"]="Restore from local or remote (with SSH)"              # <<< NEW
  ["Server Service Control"]="Manage CMDS services or reboot the server."
  ["README"]="View CMDS hybrid README / usage guide."
)

# Display order (main menu)
ORDER=(
  "Setup Wizard"
  "Switch Discovery"
  "IOS-XE Upgrade"
  "Validate IOS-XE configuration"
  "Migrate Switches"
  "Clean Configuration (New Batch Deployment)"
  "Logging"
  "Utilities"
  "Server Management"
  "Backup & Restore"            # <<< NEW (right above Server Service Control)
  "Server Service Control"
  "README"
)

is_done(){  # $1=label -> returns 0 if artifact indicates completion
  local lbl="$1" f="${DONE_FILE[$lbl]:-}"
  [[ -n "$f" ]] || return 1

  if [[ "$lbl" == "Migrate Switches" ]]; then
    if [[ -L "$f" ]]; then
      local tgt; tgt="$(readlink -f -- "$f" 2>/dev/null || true)"
      [[ -n "$tgt" && -e "$tgt" ]] || return 1
      grep -q "FAILED" "$tgt" 2>/dev/null && return 1
      return 0
    fi
    return 1
  fi

  [[ -s "$f" ]]
}

colorize_help(){  # $1=label
  local lbl="$1" extra=""
  if is_done "$lbl"; then
    extra="  \Z2\Zb(Completed)\Zn"
  fi
  printf '%b%s%b%b' "$HELP_COLOR_PREFIX" "${HELP_RAW[$lbl]:-Run $lbl}" "$HELP_COLOR_RESET" "$extra"
}

display_label(){  # $1=label -> prints label with green check / submenu marker
  local lbl="$1" text

  if [[ "$lbl" == "Server Management" ]]; then
    printf "%s" "---------------- Server Management ----------------"
    return
  fi

  if is_done "$lbl"; then
    text="$lbl  $MARK_CHECK"
  else
    text="$lbl"
  fi

  if [[ -n "${SUBMENU_FN[$lbl]:-}" ]]; then
    text="$text  >"
  fi

  printf "%s" "$text"
}

run_target(){
  local script="$1" label="$2"

  if [[ "$label" == "Server Management" ]]; then
    return 0
  fi

  if [[ -n "${SUBMENU_FN[$label]:-}" ]]; then
    "${SUBMENU_FN[$label]}"
    return 0
  fi

  clear
  if [[ -n "$script" && -f "$script" ]]; then
    set +e
    bash "$script"
    local rc=$?
    set -e

    case "$rc" in
      0) : ;;
      1|255|130|143) return 0 ;;  # Cancel/Esc/Ctrl-C -> not an error
      *) dlg --title "$label" --msgbox "Script exited with status $rc.\n\n$script" 8 72 ;;
    esac
  else
    dlg --title "Not Found" --msgbox "Cannot find:\n${script:-<none>}" 7 60
  fi
  return 0
}

# ---------- IOS-XE Upgrade submenu ----------
submenu_iosxe(){
  local SUB_TITLE="IOS-XE Upgrade"
  while true; do
    local MENU_ITEMS=()
    local -A PATH_BY_TAG=()
    local -A LABEL_BY_TAG=()
    local i=1

    local lbl1="Deploy IOS-XE"
    local path1="/root/.hybrid_admin/image_upgrade.sh"
    MENU_ITEMS+=("$i" "$lbl1" "$(colorize_help "$lbl1")"); PATH_BY_TAG["$i"]="$path1"; LABEL_BY_TAG["$i"]="$lbl1"; ((i++))

    local lbl2="Schedule Image Upgrade"
    local path2="/root/.hybrid_admin/scheduler.sh"
    MENU_ITEMS+=("$i" "$lbl2" "$(colorize_help "$lbl2")"); PATH_BY_TAG["$i"]="$path2"; LABEL_BY_TAG["$i"]="$lbl2"; ((i++))

    MENU_ITEMS+=("0" "Back" "$(printf '%bReturn to main menu%b' "$HELP_COLOR_PREFIX" "$HELP_COLOR_RESET")")

    dlg --title "$SUB_TITLE" --menu "Select an option:" 18 78 10 "${MENU_ITEMS[@]}"

    # Cancel/Esc -> return to menu.sh main (NOT exit)
    [[ $DIALOG_RC -ne 0 ]] && return 0
    [[ "$DOUT" == "0" ]] && return 0

    run_target "${PATH_BY_TAG[$DOUT]}" "${LABEL_BY_TAG[$DOUT]}"
  done
}

# ---------- Backup & Restore submenu (NEW) ----------
submenu_backup_restore(){
  local SUB_TITLE="Backup & Restore"
  local color_help; color_help(){ printf '%b%s%b' "$HELP_COLOR_PREFIX" "$1" "$HELP_COLOR_RESET"; }

  while true; do
    local MENU_ITEMS=()
    local -A PATH_BY_TAG=()
    local -A LABEL_BY_TAG=()
    local i=1

    local lbl1="Backup (Local/Remote)"
    local path1="/root/.server_admin/cmds_backup.sh"
    MENU_ITEMS+=("$i" "$lbl1" "$(color_help "${HELP_RAW[$lbl1]:-Run CMDS backups (local/remote).}")")
    PATH_BY_TAG["$i"]="$path1"; LABEL_BY_TAG["$i"]="$lbl1"; ((i++))

    local lbl2="Backup Scheduler"
    local path2="/root/.server_admin/cmds_backup_scheduler.sh"
    MENU_ITEMS+=("$i" "$lbl2" "$(color_help "${HELP_RAW[$lbl2]:-Schedule recurring backups.}")")
    PATH_BY_TAG["$i"]="$path2"; LABEL_BY_TAG["$i"]="$lbl2"; ((i++))

    local lbl3="Restore"
    local path3="/root/.server_admin/cmds_restore.sh"
    MENU_ITEMS+=("$i" "$lbl3" "$(color_help "${HELP_RAW[$lbl3]:-Restore from local/remote backups.}")")
    PATH_BY_TAG["$i"]="$path3"; LABEL_BY_TAG["$i"]="$lbl3"; ((i++))

    MENU_ITEMS+=("0" "Back" "$(color_help "Return to main menu")")

    dlg --title "$SUB_TITLE" --menu "Select an option:" 14 84 8 "${MENU_ITEMS[@]}"

    # Cancel/Esc -> return to main menu (NOT exit menu.sh)
    [[ $DIALOG_RC -ne 0 ]] && return 0
    [[ "$DOUT" == "0" ]] && return 0

    run_target "${PATH_BY_TAG[$DOUT]}" "${LABEL_BY_TAG[$DOUT]}"
  done
}

# ---------- Utilities submenu ----------
submenu_utilities(){
  local SUB_TITLE="Utilities"
  local color_help; color_help(){ printf '%b%s%b' "$HELP_COLOR_PREFIX" "$1" "$HELP_COLOR_RESET"; }

  submenu_adv_iosxe(){
    local SUB2_TITLE="Advanced IOS-XE Deployment"
    while true; do
      local MENU_ITEMS=()
      local -A PATH_BY_TAG=()
      local -A LABEL_BY_TAG=()
      local i=1

      local lbl1="Advanced IOS-XE Deployment (Interactive)"
      local path1="/root/.hybrid_admin/adv-ios-xe-upgrader/bin/adv_image_manual_main.sh"
      MENU_ITEMS+=("$i" "$lbl1" "$(color_help "${HELP_RAW[$lbl1]}")"); PATH_BY_TAG["$i"]="$path1"; LABEL_BY_TAG["$i"]="$lbl1"; ((i++))

      local lbl2="Advanced IOS-XE Deployment (Scheduled)"
      local path2="/root/.hybrid_admin/adv-ios-xe-upgrader/bin/adv_image_schedule_main.sh"
      MENU_ITEMS+=("$i" "$lbl2" "$(color_help "${HELP_RAW[$lbl2]}")"); PATH_BY_TAG["$i"]="$path2"; LABEL_BY_TAG["$i"]="$lbl2"; ((i++))

      local lbl3="View Advanced Schedules"
      local path3="/root/.hybrid_admin/adv-ios-xe-upgrader/bin/view_schedule.sh"
      MENU_ITEMS+=("$i" "$lbl3" "$(color_help "${HELP_RAW[$lbl3]}")"); PATH_BY_TAG["$i"]="$path3"; LABEL_BY_TAG["$i"]="$lbl3"; ((i++))

      MENU_ITEMS+=("0" "Back" "$(color_help "Return to Utilities")")

      dlg --title "$SUB2_TITLE" --menu "Select an option:" 16 86 10 "${MENU_ITEMS[@]}"
      [[ $DIALOG_RC -ne 0 ]] && return 0
      [[ "$DOUT" == "0" ]] && return 0

      run_target "${PATH_BY_TAG[$DOUT]}" "${LABEL_BY_TAG[$DOUT]}"
    done
  }

  while true; do
    local MENU_ITEMS=()
    local -A PATH_BY_TAG=()
    local -A LABEL_BY_TAG=()
    local i=1

    local lbl1="Switch UP/Down Status"
    local path1="/root/.hybrid_admin/ping.sh"
    MENU_ITEMS+=("$i" "$lbl1" "$(color_help "Continuous ping monitor for selected switches (UP/DOWN).")")
    PATH_BY_TAG["$i"]="$path1"; LABEL_BY_TAG["$i"]="$lbl1"; ((i++))

    local lbl_adv="Advanced IOS-XE deployment"
    MENU_ITEMS+=("$i" "$lbl_adv" "$(color_help "${HELP_RAW[$lbl_adv]}")")
    PATH_BY_TAG["$i"]="" ; LABEL_BY_TAG["$i"]="$lbl_adv"; ((i++))

    local lbl2="IOS-XE Image Management"
    local path2="/root/.hybrid_admin/image_management.sh"
    MENU_ITEMS+=("$i" "$lbl2" "$(color_help "Manage IOS-XE image files (list, inspect, and clean up).")")
    PATH_BY_TAG["$i"]="$path2"; LABEL_BY_TAG["$i"]="$lbl2"; ((i++))

    local lbl3="CLI Updater"
    local path3="/root/.hybrid_admin/cli_updater.sh"
    MENU_ITEMS+=("$i" "$lbl3" "$(color_help "Run ad-hoc CLI command packs on selected switches.")")
    PATH_BY_TAG["$i"]="$path3"; LABEL_BY_TAG["$i"]="$lbl3"; ((i++))

    local lbl4="Backup Config Viewer"
    local path4="/root/.hybrid_admin/back_config_viewer.sh"
    MENU_ITEMS+=("$i" "$lbl4" "$(color_help "Browse and search saved switch backup configs.")")
    PATH_BY_TAG["$i"]="$path4"; LABEL_BY_TAG["$i"]="$lbl4"; ((i++))

    local lbl5="CMDS Updater"
    local path5="/root/.server_admin/cmds_updater.sh"
    MENU_ITEMS+=("$i" "$lbl5" "$(color_help "${HELP_RAW[$lbl5]}")")
    PATH_BY_TAG["$i"]="$path5"; LABEL_BY_TAG["$i"]="$lbl5"; ((i++))

    MENU_ITEMS+=("0" "Back" "$(color_help "Return to main menu")")

    dlg --title "$SUB_TITLE" --menu "Select a utility:" 17 84 12 "${MENU_ITEMS[@]}"
    [[ $DIALOG_RC -ne 0 ]] && return 0
    [[ "$DOUT" == "0" ]] && return 0

    if [[ "${LABEL_BY_TAG[$DOUT]}" == "Advanced IOS-XE deployment" ]]; then
      submenu_adv_iosxe
      continue
    fi

    run_target "${PATH_BY_TAG[$DOUT]}" "${LABEL_BY_TAG[$DOUT]}"
  done
}

# ---------- Server Service Control submenu ----------
submenu_server_services(){
  local SUB_TITLE="Server Service Control"
  local color_help; color_help(){ printf '%b%s%b' "$HELP_COLOR_PREFIX" "$1" "$HELP_COLOR_RESET"; }

  while true; do
    local MENU_ITEMS=()
    local -A PATH_BY_TAG=()
    local -A LABEL_BY_TAG=()
    local i=1

    local lbl1="Manage CMDS Services"
    local path1="/root/.server_admin/service_control.sh"
    MENU_ITEMS+=("$i" "$lbl1" "$(color_help "Start/stop/restart CMDS services via dialog.")")
    PATH_BY_TAG["$i"]="$path1"; LABEL_BY_TAG["$i"]="$lbl1"; ((i++))

    if [[ -f /etc/kea/kea-dhcp4.conf ]]; then
      local lbl_dhcp="DHCP Administration"
      local path_dhcp="/root/.server_admin/dhcp_admin.sh"
      MENU_ITEMS+=("$i" "$lbl_dhcp" "$(color_help "Administer Kea DHCP configuration and leases.")")
      PATH_BY_TAG["$i"]="$path_dhcp"; LABEL_BY_TAG["$i"]="$lbl_dhcp"; ((i++))
    fi

    local lbl2="Reboot Server"
    MENU_ITEMS+=("$i" "$lbl2" "$(color_help "Safely reboot this server (confirmation required).")")
    PATH_BY_TAG["$i"]="" ; LABEL_BY_TAG["$i"]="$lbl2"; ((i++))

    MENU_ITEMS+=("0" "Back" "$(color_help "Return to main menu")")

    dlg --title "$SUB_TITLE" --menu "Select an option:" 14 78 8 "${MENU_ITEMS[@]}"
    [[ $DIALOG_RC -ne 0 ]] && return 0
    [[ "$DOUT" == "0" ]] && return 0

    local label="${LABEL_BY_TAG[$DOUT]}"
    if [[ "$label" == "Reboot Server" ]]; then
      if [[ $EUID -ne 0 ]]; then
        dlg --title "Permission required" --msgbox "Reboot requires root privileges." 7 60
        continue
      fi
      set +e
      dialog --no-shadow --backtitle "$BACKTITLE" --title "Confirm Reboot" --yesno \
"Are you sure you want to reboot this server now?

Active tasks or SSH sessions may be interrupted." 10 70
      local yn=$?
      set -e
      if (( yn == 0 )); then
        clear
        systemctl reboot || reboot || shutdown -r now
        exit 0
      fi
    else
      run_target "${PATH_BY_TAG[$DOUT]}" "$label"
    fi
  done
}

# ---------- Main menu loop ----------
while true; do
  MENU_ITEMS=()
  declare -A PATH_BY_TAG=()
  declare -A LABEL_BY_TAG=()

  i=1
  for label in "${ORDER[@]}"; do
    shown="$(display_label "$label")"
    MENU_ITEMS+=("$i" "$shown" "$(colorize_help "$label")")
    PATH_BY_TAG["$i"]="${ITEMS[$label]}"
    LABEL_BY_TAG["$i"]="$label"
    ((i++))
  done
  MENU_ITEMS+=("0" "Back" "$(printf '%bReturn to previous menu%b' "$HELP_COLOR_PREFIX" "$HELP_COLOR_RESET")")

  dlg --title "$TITLE" --menu "Select an option:" 22 78 10 "${MENU_ITEMS[@]}"

  # Cancel/Esc in MAIN menu exits menu.sh (returns to parent launcher)
  [[ $DIALOG_RC -ne 0 ]] && exit 0

  [[ "$DOUT" == "0" ]] && exit 0
  run_target "${PATH_BY_TAG[$DOUT]}" "${LABEL_BY_TAG[$DOUT]}"
done